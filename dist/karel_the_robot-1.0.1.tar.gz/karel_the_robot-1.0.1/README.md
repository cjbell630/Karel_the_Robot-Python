## Please click [here](https://cjbell630.github.io/Karel_the_Robot-Python) for documentation! ##
Alternatively, the raw HTML file can be found in [/index.html](/index.html)

***All credit to the concept and ideas belong to the original Karel team (made in Java). This is a PORT, not an original creation by any means.***
